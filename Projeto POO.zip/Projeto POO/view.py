from Models.cliente import Cliente, ClienteDAO
from Models.produto import Produto, ProdutoDAO
from Models.categoria import Categoria, CategoriaDAO 
from Models.favoritos import Favoritos, FavoritosDAO
from Models.venda import Venda, VendaDAO
from Models.vendaitem import VendaItem, VendaItemDAO
from datetime import datetime

class View:
    
    @staticmethod
    def criar_admim():
        for obj in View.cliente_listar():
            if "admin@abc.com" in obj.get_email(): return
        View.cliente_inserir("Admin", "admin@abc.com", "000000000", "admin123")

    @staticmethod
    def autentica_usuario(email, senha):
        clientes = ClienteDAO.listar()
        for info in clientes:
            if (info.get_email() == email) and (info.get_senha() == senha):
                return info.get_id()
        raise ValueError("Usuário ou senha inválidos.")

    #   Operações  Cliente  
    @staticmethod
    def cliente_inserir(nome, email, fone, senha):
        c = Cliente(1, nome, email, fone, senha)
        ClienteDAO.inserir(c)

    @staticmethod
    def cliente_listar():
        return ClienteDAO.listar()

    @staticmethod
    def cliente_listar_id(id):
        return ClienteDAO.listar_id(id)

    @staticmethod
    def cliente_atualizar(id, nome, email, fone, senha):
        c = Cliente(id, nome, email, fone, senha)
        ClienteDAO.atualizar(c)
    
    @staticmethod
    def cliente_excluir(id):
        ClienteDAO.excluir(id)


    # Operações Categoria 
    @staticmethod
    def categoria_listar():
        return CategoriaDAO.listar()
    
    @staticmethod
    def categoria_inserir(descricao):
        c = Categoria(1, descricao)
        CategoriaDAO.inserir(c)

    @staticmethod
    def categoria_listar_id(id):
        return CategoriaDAO.listar_id(id)
    
    @staticmethod
    def categoria_atualizar(id, descricao):
        c = Categoria(id, descricao)
        CategoriaDAO.atualizar(c)
    
    @staticmethod
    def categoria_excluir(id):
        CategoriaDAO.excluir(id)


    # Operações  Produto 
    @staticmethod
    def produto_inserir(descricao, preco, estoque, id_categoria):
        if CategoriaDAO.listar_id(id_categoria) is None:
            raise ValueError("Categoria não encontrada.")
        p = Produto(1, descricao, preco, estoque, id_categoria)
        ProdutoDAO.inserir(p)

    @staticmethod
    def produto_listar():
        return ProdutoDAO.listar()
    
    @staticmethod
    def produto_listar_id(id):
        return ProdutoDAO.listar_id(id)
    
    @staticmethod
    def produto_atualizar(id, descricao, preco, estoque, id_categoria):
        if CategoriaDAO.listar_id(id_categoria) is None:
            raise ValueError("Categoria não encontrada.")
        p = Produto(id, descricao, preco, estoque, id_categoria)
        ProdutoDAO.atualizar(p)

    @staticmethod
    def produto_reajustar(percentual):
        for p in ProdutoDAO.listar():
            novo_preco = p.get_preco() * (1 + percentual/100)
            p.set_preco(novo_preco)
            ProdutoDAO.atualizar(p)

    @staticmethod
    def produto_excluir(id):   
        ProdutoDAO.excluir(id)


    # Operações Venda/Carrinho
    @staticmethod
    def carrinho_obter_venda_aberta(id_cliente):
        vendas = VendaDAO.listar()
        for v in vendas:
            if v.get_id_cliente() == id_cliente and v.get_carrinho() == True:
                return v
                
        # Se não existe carrinho aberto, cria um
        nova_venda = Venda(1, datetime.now().strftime('%d/%m/%Y'), True, 0.0, id_cliente)
        VendaDAO.inserir(nova_venda)
        
        # Retorna a venda que acabou de criar
        return nova_venda

    @staticmethod
    def carrinho_inserir_produto(id_cliente, id_produto, qtd):
        venda = View.carrinho_obter_venda_aberta(id_cliente)
        produto = ProdutoDAO.listar_id(id_produto)
        
        if produto is None:
            raise ValueError("Produto não encontrado.")
        if produto.get_estoque() < qtd:
            raise ValueError("Estoque insuficiente.")

        itens = VendaItemDAO.listar()
        item_existente = None
        for i in itens:
            if i.get_id_venda() == venda.get_id() and i.get_id_produto() == id_produto:
                item_existente = i
                break

        if item_existente:
            nova_qtd = item_existente.get_qtd() + qtd
            if produto.get_estoque() < nova_qtd:
                raise ValueError("Estoque total insuficiente para a quantidade somada.")
            item_existente.set_qtd(nova_qtd)
            VendaItemDAO.atualizar(item_existente)
        else:
            novo_item = VendaItem(1, qtd, produto.get_preco(), venda.get_id(), id_produto)
            VendaItemDAO.inserir(novo_item)

    @staticmethod
    def carrinho_listar_itens(id_cliente):
        venda = View.carrinho_obter_venda_aberta(id_cliente)
        return [i for i in VendaItemDAO.listar() if i.get_id_venda() == venda.get_id()]

    @staticmethod
    def carrinho_comprar(id_cliente):
        venda = View.carrinho_obter_venda_aberta(id_cliente)
        itens = View.carrinho_listar_itens(id_cliente)
        
        if not itens:
            raise ValueError("Carrinho vazio.")
        
        total = 0.0
        for i in itens:
            produto = ProdutoDAO.listar_id(i.get_id_produto())
            produto.set_estoque(produto.get_estoque() - i.get_qtd())
            ProdutoDAO.atualizar(produto)
            total += i.get_qtd() * i.get_preco()

        venda.set_total(total)
        venda.set_carrinho(False)
        venda.set_data(datetime.now().strftime('%d/%m/%Y'))
        VendaDAO.atualizar(venda)

    @staticmethod
    def compras_listar_cliente(id_cliente):
        return [v for v in VendaDAO.listar() if v.get_id_cliente() == id_cliente and v.get_carrinho() == False]

    @staticmethod
    def vendas_listar_todas():
        return [v for v in VendaDAO.listar() if v.get_carrinho() == False]


    #  Nova Funcionalidade: Favoritos  
    @staticmethod
    def favoritos_inserir(id_cliente, id_produto):
        produto = ProdutoDAO.listar_id(id_produto)
        
        # Verifica se o produto existe
        if produto is None:
            raise ValueError("Produto não encontrado no sistema.")
            
        # Verifica se o produto esta disponível para compra
        if produto.get_estoque() <= 0:
            raise ValueError("Este produto está sem estoque e não pode ser favoritado no momento.")
            
        
        descricao = produto.get_descricao()
            

        favs = Favoritos(1, descricao, id_cliente, id_produto)
        FavoritosDAO.inserir(favs)

    @staticmethod
    def favoritos_listar(id_cliente):
        return [f for f in FavoritosDAO.listar() if f.get_cliente_id() == id_cliente]

    @staticmethod
    def favoritos_excluir(id_favorito):
        FavoritosDAO.excluir(id_favorito)