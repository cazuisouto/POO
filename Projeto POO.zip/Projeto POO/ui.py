from view import View

class UI:
    cliente_id = 0
    cliente_nome = ""

    @staticmethod
    def main():
        View.criar_admim()
        op = -1
        while op != 0:
            op = UI.menu()
            if op == 0:
                print("Saindo do sistema...")
                break
            
            try:
                # Rotas do Visitante
                if UI.cliente_id == 0:
                    if op == 1: UI.visitante_entrar()
                    elif op == 2: UI.visitante_abrir_conta()
                
                # Rotas do Admin
                elif UI.cliente_nome == "Admin":
                    if op == 1: UI.cliente_listar()
                    elif op == 2: UI.cliente_inserir()
                    elif op == 3: UI.cliente_atualizar()
                    elif op == 4: UI.cliente_excluir()
                    elif op == 5: UI.categoria_listar()
                    elif op == 6: UI.categoria_inserir()
                    elif op == 7: UI.categoria_atualizar()
                    elif op == 8: UI.categoria_excluir()
                    elif op == 9: UI.produto_listar()
                    elif op == 10: UI.produto_inserir()
                    elif op == 11: UI.produto_atualizar()
                    elif op == 12: UI.produto_excluir()
                    elif op == 13: UI.produto_reajustar()
                    elif op == 14: UI.vendas_listar()
                    elif op == 99: UI.sair_conta()

                # Rotas do Cliente
                else:
                    if op == 1: UI.produto_listar()
                    elif op == 2: UI.carrinho_inserir()
                    elif op == 3: UI.carrinho_visualizar()
                    elif op == 4: UI.carrinho_comprar()
                    elif op == 5: UI.compras_listar()
                    elif op == 6: UI.favoritos_inserir()
                    elif op == 7: UI.favoritos_listar()
                    elif op == 8: UI.favoritos_excluir()
                    elif op == 99: UI.sair_conta()

            except Exception as e:
                print(f"Houve um erro: {e}")

    @staticmethod
    def menu():
        print(f"\n Sistema de Comércio Eletrônico ")
        if UI.cliente_id == 0:
            print("1 - Entrar no sistema")
            print("2 - Abrir conta")
            print("0 - Sair")
            return int(input("Escolha uma opção: "))
            
        elif UI.cliente_nome == "Admin":
            print("Bem-vindo, Admin!")
            print("1 - Listar Clientes  | 2 - Inserir Cliente   | 3 - Atualizar Cliente | 4 - Excluir Cliente")
            print("5 - Listar Categoria | 6 - Inserir Categoria | 7 - Atualizar Categ.  | 8 - Excluir Categ.")
            print("9 - Listar Produto   | 10 - Inserir Produto  | 11 - Atualizar Prod.  | 12 - Excluir Prod.")
            print("13 - Reajustar Preços| 14 - Listar Todas as Vendas")
            print("------------------------------------------------------------------------------------------\n")
            print("99 - Sair da conta (Logout)")
            print("0 - Encerrar a aplicação")
            return int(input("\nEscolha uma opção: "))
            
        else:
            print(f"Bem-vindo(a), {UI.cliente_nome}!")
            print("1 - Ver Produtos disponíveis")
            print("2 - Inserir Produto no Carrinho")
            print("3 - Visualizar Carrinho")
            print("4 - Comprar Carrinho")
            print("5 - Listar Minhas Compras")
            print("6 - Adicionar Produto aos Favoritos")
            print("7 - Ver Meus Favoritos")
            print("8 - Excluir Favorito")
            print("99 - Sair da conta (Logout)")
            print("0 - Encerrar a aplicação")
            return int(input("\nEscolha uma opção: "))

    #  Visitante 
    @staticmethod
    def visitante_entrar():
        email = input("E-mail: ")
        senha = input("Senha: ")
        UI.cliente_id = View.autentica_usuario(email, senha)
        UI.cliente_nome = View.cliente_listar_id(UI.cliente_id).get_nome()

    @staticmethod
    def visitante_abrir_conta():
        View.cliente_inserir(
            input("Nome: "), 
            input("E-mail: "), 
            input("Telefone: "), 
            input("Senha: ")
        )
        print("Conta criada com sucesso!")

    @staticmethod #método criado pra sair da conta e ja atribuir um id e nada ao nome do usuário
    def sair_conta():
        UI.cliente_id = 0
        UI.cliente_nome = ""

    #  CRUD Cliente (Admin) 
    @staticmethod
    def cliente_listar():
        for c in View.cliente_listar(): print(c)

    @staticmethod
    def cliente_inserir():
        View.cliente_inserir(input("Nome: "), input("E-mail: "), input("Telefone: "), input("Senha: "))

    @staticmethod
    def cliente_atualizar():
        View.cliente_atualizar(int(input("ID do Cliente: ")), input("Nome: "), input("E-mail: "), input("Telefone: "), input("Senha: "))

    @staticmethod
    def cliente_excluir():
        View.cliente_excluir(int(input("ID do Cliente: ")))

    #  CRUD Categoria (Admin) 
    @staticmethod
    def categoria_listar():
        for c in View.categoria_listar(): print(c)

    @staticmethod
    def categoria_inserir():
        View.categoria_inserir(input("Descrição da categoria: "))

    @staticmethod
    def categoria_atualizar():
        View.categoria_atualizar(int(input("ID da Categoria: ")), input("Nova Descrição: "))

    @staticmethod
    def categoria_excluir():
        View.categoria_excluir(int(input("ID da Categoria: ")))

    #  CRUD Produto (Admin/Cliente) 
    @staticmethod
    def produto_listar():
        for p in View.produto_listar(): print(p)

    @staticmethod
    def produto_inserir():
        View.produto_inserir(input("Descrição: "), float(input("Preço: ")), int(input("Estoque inicial: ")), int(input("ID Categoria: ")))

    @staticmethod
    def produto_atualizar():
        View.produto_atualizar(int(input("ID Produto: ")), input("Descrição: "), float(input("Preço: ")), int(input("Estoque: ")), int(input("ID Categoria: ")))

    @staticmethod
    def produto_reajustar():
        View.produto_reajustar(float(input("Percentual de reajuste (%): ")))

    @staticmethod
    def produto_excluir():
        View.produto_excluir(int(input("ID Produto: ")))

    @staticmethod
    def vendas_listar():
        vendas = View.vendas_listar_todas()
        for v in vendas:
            print(v)

    #  Área do Cliente 
    @staticmethod
    def carrinho_inserir():
        View.carrinho_inserir_produto(UI.cliente_id, int(input("ID do Produto: ")), int(input("Quantidade: ")))
        print("Produto adicionado ao carrinho.")

    @staticmethod
    def carrinho_visualizar():
        itens = View.carrinho_listar_itens(UI.cliente_id)
        if not itens:
            print("Seu carrinho está vazio.")
        else:
            total_geral = 0
            print("\n--- SEU CARRINHO DE COMPRAS ---")
            for i in itens:
                p = View.produto_listar_id(i.get_id_produto())
                subtotal = i.get_qtd() * i.get_preco()
                total_geral += subtotal
                
                nome_produto = p.get_descricao() if p else "Produto não identificado"
                
                print(f"- {nome_produto} (ID: {i.get_id_produto()}) | Qtd: {i.get_qtd()} | Preço Un: R${i.get_preco():.2f} | Subtotal: R${subtotal:.2f}")
            print(f"--------------------------------")
            print(f"Total Geral do Carrinho: R${total_geral:.2f}")

    @staticmethod
    def carrinho_comprar():
        View.carrinho_comprar(UI.cliente_id)
        print("Compra finalizada com sucesso!")

    @staticmethod
    def compras_listar():
        vendas = View.compras_listar_cliente(UI.cliente_id)
        if not vendas: print("Nenhuma compra encontrada.")
        for v in vendas:
            print(v)

    @staticmethod
    def favoritos_inserir():
        id_produto = int(input("ID do Produto que deseja favoritar: "))
        
        View.favoritos_inserir(UI.cliente_id, id_produto)
        print("Produto adicionado aos favoritos com sucesso!")

    @staticmethod
    def favoritos_listar():
        favs = View.favoritos_listar(UI.cliente_id)
        if not favs: 
            print("Nenhum favorito cadastrado.")
        else:
            print("\n------- MEUS FAVORITOS -------")
            for f in favs:
                p = View.produto_listar_id(f.get_produto_id())
                
                nome_produto = p.get_descricao() if p else "Produto Indisponível/Excluído"
                print(f"ID Favorito: {f.get_id()} | Produto: {nome_produto}")
            print("------------------------------------")
    @staticmethod
    def favoritos_excluir():
        View.favoritos_excluir(int(input("ID do Favorito para excluir: ")))


if __name__ == "__main__":
    UI.main()